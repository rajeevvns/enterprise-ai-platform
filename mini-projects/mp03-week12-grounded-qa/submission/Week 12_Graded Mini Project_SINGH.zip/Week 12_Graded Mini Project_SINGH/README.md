# Week 12 Graded Mini Project - SINGH

## Required deliverables

- `mp3_grounded_qa.py`: grounded Q&A assistant with all four functions implemented.
- `mp3_eval.txt`: actual nine-question evaluation output.
- `data/learner_questions.jsonl`: two answerable questions across different stories
  (one multi-hop), plus one should-abstain question.
- `mp3_reflection.md`: grounding, abstention, citations, metrics, and lessons.
- `MP3_Week12_demo.mov`: supplied screen recording, compressed and played at
  1.12x speed to fit the 2-3 minute limit. All recording content is retained.

The original recording is unchanged outside this submission package.
`supplemental-demo/mp3_demo.mp4` is an additional 2:30 narrated replay of actual
captured output showing two cited answers, one refusal, and the evaluation table.
Its narration is computer-generated; it is not a live screen recording.
`supplemental-demo/mp3_demo_transcript.txt` contains its narration and output.

## Run

Open a terminal in this extracted folder:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` with your own OpenAI and Qdrant credentials. A Vocareum gateway key
also requires `export OPENAI_BASE_URL="YOUR_ASSIGNED_BASE_URL"`. Never share or
commit `.env`; no credentials are included in this ZIP.

```bash
source .env
env -u OPENAI_API_KEY -u QDRANT_URL -u QDRANT_API_KEY python mp3_grounded_qa.py selftest
python mp3_grounded_qa.py ingest
python mp3_grounded_qa.py ask
python mp3_grounded_qa.py eval
```

The CLI uses top-10 retrieval because `answer` explicitly passes its default
`k=10` to `retrieve`, overriding the helper's standalone default of 3.
The threshold used in the recorded evaluation is 0.30. The client is pinned
to Qdrant 1.20.x and uses `query_points`.

`ingest` recreates `mp3_sherlock`, replacing its existing contents; use a collection
that is dedicated to this project. OpenAI models are `gpt-4o-mini` and
`text-embedding-3-small`, used directly with the SDK.

The corpus, both question sets, dependency manifest, safe environment template,
and FAQ are included so the project can run independently. Live commands need
credentials and incur service usage; the offline selftest does not.

## Evaluation limits

The saved results are retrieval hit rate 1.0, grounded & cited rate 1.0,
abstention accuracy 1.0, and hallucination rate 0.0, over six answerable and three
should-abstain questions. This small set does not establish production reliability,
and valid source numbers do not automatically establish claim support.
